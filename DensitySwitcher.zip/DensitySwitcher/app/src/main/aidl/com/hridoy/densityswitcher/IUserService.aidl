package com.hridoy.densityswitcher;

// This runs inside Shizuku's privileged process (shell UID), not inside our normal app process.
interface IUserService {
    void execute(String cmd);
    String runAndGetOutput(String cmd);
    void destroy();
}
