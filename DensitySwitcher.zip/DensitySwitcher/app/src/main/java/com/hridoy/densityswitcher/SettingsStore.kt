package com.hridoy.densityswitcher

import android.content.Context

/**
 * Tiny wrapper around SharedPreferences so the Game DPI and Default DPI
 * can be changed anytime from the app's UI, no code edit / rebuild needed.
 */
object SettingsStore {

    private const val PREFS = "density_switcher_prefs"
    private const val KEY_GAME_DPI = "game_dpi"
    private const val KEY_DEFAULT_DPI = "default_dpi"
    private const val KEY_OPEN_ENABLED = "open_enabled"
    private const val KEY_CLOSE_ENABLED = "close_enabled"

    private const val FALLBACK_GAME_DPI = 338
    private const val FALLBACK_DEFAULT_DPI = 411

    fun getGameDpi(context: Context): Int {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return prefs.getInt(KEY_GAME_DPI, FALLBACK_GAME_DPI)
    }

    fun getDefaultDpi(context: Context): Int {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return prefs.getInt(KEY_DEFAULT_DPI, FALLBACK_DEFAULT_DPI)
    }

    /** Whether the "game opened -> apply Game DPI" rule is active. */
    fun isOpenEnabled(context: Context): Boolean {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getBoolean(KEY_OPEN_ENABLED, true)
    }

    /** Whether the "game closed -> apply Default DPI" rule is active. */
    fun isCloseEnabled(context: Context): Boolean {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getBoolean(KEY_CLOSE_ENABLED, true)
    }

    fun save(context: Context, gameDpi: Int, defaultDpi: Int, openEnabled: Boolean, closeEnabled: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putInt(KEY_GAME_DPI, gameDpi)
            .putInt(KEY_DEFAULT_DPI, defaultDpi)
            .putBoolean(KEY_OPEN_ENABLED, openEnabled)
            .putBoolean(KEY_CLOSE_ENABLED, closeEnabled)
            .apply()
    }
}
