package com.hridoy.densityswitcher

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.hridoy.densityswitcher.databinding.ActivityMainBinding
import rikka.shizuku.Shizuku

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private val permissionListener = Shizuku.OnRequestPermissionResultListener { _, grantResult ->
        if (grantResult == android.content.pm.PackageManager.PERMISSION_GRANTED) {
            ShizukuManager.bindIfNeeded()
            updateStatus()
        } else {
            binding.statusText.text = "Shizuku permission denied. আবার চাপুন।"
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        Shizuku.addRequestPermissionResultListener(permissionListener)

        // Load whatever was saved last time (or the defaults, first run).
        binding.inputGameDpi.setText(SettingsStore.getGameDpi(this).toString())
        binding.inputDefaultDpi.setText(SettingsStore.getDefaultDpi(this).toString())

        binding.btnSave.setOnClickListener { saveValues() }

        binding.btnAccessibility.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        binding.btnShizuku.setOnClickListener {
            ShizukuManager.requestPermission()
        }

        updateStatus()
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
    }

    private fun saveValues() {
        val gameDpi = binding.inputGameDpi.text.toString().toIntOrNull()
        val defaultDpi = binding.inputDefaultDpi.text.toString().toIntOrNull()

        if (gameDpi == null || defaultDpi == null || gameDpi <= 0 || defaultDpi <= 0) {
            Toast.makeText(this, "দুটো বক্সেই একটা সঠিক নাম্বার দিন", Toast.LENGTH_SHORT).show()
            return
        }

        SettingsStore.save(this, gameDpi, defaultDpi)
        Toast.makeText(this, "Saved: Game=$gameDpi, Default=$defaultDpi", Toast.LENGTH_SHORT).show()
    }

    private fun updateStatus() {
        binding.statusText.text = if (ShizukuManager.hasPermission()) {
            "Shizuku: সংযুক্ত ✓  |  এখনো না করলে Accessibility Service চালু করুন।"
        } else {
            "সেটআপ বাকি: Accessibility চালু করুন এবং Shizuku permission দিন।"
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        Shizuku.removeRequestPermissionResultListener(permissionListener)
    }
}
