package com.hridoy.densityswitcher

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.hridoy.densityswitcher.databinding.ActivityMainBinding
import rikka.shizuku.Shizuku

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private val permissionListener = Shizuku.OnRequestPermissionResultListener { _, grantResult ->
        if (grantResult == android.content.pm.PackageManager.PERMISSION_GRANTED) {
            ShizukuManager.bindIfNeeded()
            updateStatus()
        } else {
            binding.statusText.text = "Shizuku permission denied. Tap the button again."
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        Shizuku.addRequestPermissionResultListener(permissionListener)

        // Load whatever was saved last time (or the defaults, first run).
        binding.inputGameDpi.setText(SettingsStore.getGameDpi(this).toString())
        binding.inputDefaultDpi.setText(SettingsStore.getDefaultDpi(this).toString())
        binding.switchOpen.isChecked = SettingsStore.isOpenEnabled(this)
        binding.switchClose.isChecked = SettingsStore.isCloseEnabled(this)

        binding.btnSave.setOnClickListener { saveValues() }

        binding.btnAccessibility.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        binding.btnShizuku.setOnClickListener {
            ShizukuManager.requestPermission()
        }

        binding.btnCheckDensity.setOnClickListener {
            Toast.makeText(this, "Checking...", Toast.LENGTH_SHORT).show()
            ShizukuManager.getCurrentDensity { result ->
                runOnUiThread {
                    androidx.appcompat.app.AlertDialog.Builder(this)
                        .setTitle("Actual current density (from system)")
                        .setMessage(result)
                        .setPositiveButton("OK", null)
                        .show()
                }
            }
        }

        updateStatus()
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
    }

    private fun saveValues() {
        val gameDpi = binding.inputGameDpi.text.toString().toIntOrNull()
        val defaultDpi = binding.inputDefaultDpi.text.toString().toIntOrNull()

        if (gameDpi == null || defaultDpi == null || gameDpi <= 0 || defaultDpi <= 0) {
            Toast.makeText(this, "Please enter a valid number in both fields", Toast.LENGTH_SHORT).show()
            return
        }

        SettingsStore.save(this, gameDpi, defaultDpi, binding.switchOpen.isChecked, binding.switchClose.isChecked)
        Toast.makeText(this, "Saved: Game=$gameDpi, Default=$defaultDpi", Toast.LENGTH_SHORT).show()
    }

    private fun updateStatus() {
        binding.statusText.text = if (ShizukuManager.hasPermission()) {
            "Shizuku: connected ✓  |  Also enable the Accessibility Service if you haven't yet."
        } else {
            "Setup needed: enable the Accessibility Service and grant Shizuku permission below."
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        Shizuku.removeRequestPermissionResultListener(permissionListener)
    }
}
