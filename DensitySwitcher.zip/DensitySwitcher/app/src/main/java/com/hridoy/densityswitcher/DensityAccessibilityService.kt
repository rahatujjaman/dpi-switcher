package com.hridoy.densityswitcher

import android.accessibilityservice.AccessibilityService
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent

class DensityAccessibilityService : AccessibilityService() {

    companion object {
        // Only the target game package is fixed in code. The DPI values
        // themselves are read from SettingsStore (editable in the app UI).
        const val TARGET_PACKAGE = "com.dts.freefireth"

        // How long to wait for the window state to "settle" before actually
        // acting. Android fires several window-state-changed events in quick
        // succession during a real app switch (launcher, recents, overlays),
        // and acting on every single one causes the density to flip back and
        // forth ("race condition"), which looks like random / reversed values.
        private const val SETTLE_DELAY_MS = 400L
    }

    private var isGameForeground = false
    private val handler = Handler(Looper.getMainLooper())
    private var pendingCheck: Runnable? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        // Pre-bind to Shizuku the moment the service starts, so the very
        // first game launch doesn't have to wait for a fresh bind.
        ShizukuManager.bindIfNeeded()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return

        val pkg = event.packageName?.toString() ?: return

        // Cancel any check that was waiting to run, and schedule a fresh one.
        // Only the LAST package seen after things settle down actually matters.
        pendingCheck?.let { handler.removeCallbacks(it) }

        val check = Runnable { applyDensityFor(pkg) }
        pendingCheck = check
        handler.postDelayed(check, SETTLE_DELAY_MS)
    }

    private fun applyDensityFor(pkg: String) {
        val isGameNow = pkg == TARGET_PACKAGE

        if (isGameNow && !isGameForeground) {
            isGameForeground = true
            ShizukuManager.setDensity(SettingsStore.getGameDpi(applicationContext))
        } else if (!isGameNow && isGameForeground) {
            isGameForeground = false
            ShizukuManager.setDensity(SettingsStore.getDefaultDpi(applicationContext))
        }
    }

    override fun onInterrupt() {
        pendingCheck?.let { handler.removeCallbacks(it) }
    }
}
