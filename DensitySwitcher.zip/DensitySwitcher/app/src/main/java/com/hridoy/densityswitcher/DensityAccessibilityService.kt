package com.hridoy.densityswitcher

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

class DensityAccessibilityService : AccessibilityService() {

    companion object {
        // Only the target game package is fixed in code. The DPI values
        // themselves are read from SettingsStore (editable in the app UI).
        const val TARGET_PACKAGE = "com.dts.freefireth"
    }

    private var isGameForeground = false

    override fun onServiceConnected() {
        super.onServiceConnected()
        // Pre-bind to Shizuku the moment the service starts, so the very
        // first game launch doesn't have to wait for a fresh bind.
        ShizukuManager.bindIfNeeded()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return

        val pkg = event.packageName?.toString() ?: return

        if (pkg == TARGET_PACKAGE && !isGameForeground) {
            isGameForeground = true
            ShizukuManager.setDensity(SettingsStore.getGameDpi(applicationContext))
        } else if (pkg != TARGET_PACKAGE && isGameForeground) {
            isGameForeground = false
            ShizukuManager.setDensity(SettingsStore.getDefaultDpi(applicationContext))
        }
    }

    override fun onInterrupt() {
        // Required override, nothing to clean up.
    }
}
