package com.hridoy.densityswitcher

import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.os.IBinder
import rikka.shizuku.Shizuku

/**
 * One shared connection to the privileged UserService, reused by both
 * MainActivity (for the permission-request button) and the
 * AccessibilityService (for the actual density switching).
 */
object ShizukuManager {

    private const val REQUEST_CODE = 1001
    private var userService: IUserService? = null
    private var bound = false

    private val userServiceArgs = Shizuku.UserServiceArgs(
        ComponentName("com.hridoy.densityswitcher", UserService::class.java.name)
    )
        .daemon(false)
        .processNameSuffix("density")
        .debuggable(false)
        .version(1)

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName, binder: IBinder) {
            userService = IUserService.Stub.asInterface(binder)
            bound = true
        }

        override fun onServiceDisconnected(name: ComponentName) {
            userService = null
            bound = false
        }
    }

    fun hasPermission(): Boolean {
        return try {
            Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED
        } catch (e: Exception) {
            false
        }
    }

    fun requestPermission() {
        try {
            if (!hasPermission()) {
                Shizuku.requestPermission(REQUEST_CODE)
            } else {
                bindIfNeeded()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun bindIfNeeded() {
        if (!bound && hasPermission()) {
            try {
                Shizuku.bindUserService(userServiceArgs, connection)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    /** The only function the rest of the app actually needs. */
    fun setDensity(dpi: Int) {
        bindIfNeeded()
        userService?.execute("wm density $dpi")
    }

    /** Reads back the ACTUAL current density from the system - no guessing by eye. */
    fun getCurrentDensity(callback: (String) -> Unit) {
        Thread {
            bindIfNeeded()
            var waited = 0
            while (!bound && waited < 20) {
                Thread.sleep(100)
                waited++
            }
            val result = try {
                userService?.runAndGetOutput("wm density") ?: "Shizuku user service not connected yet."
            } catch (e: Exception) {
                "Error: ${e.message}"
            }
            callback(result)
        }.start()
    }
}
