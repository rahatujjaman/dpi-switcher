package com.hridoy.densityswitcher

/**
 * IMPORTANT: This class does NOT run inside our normal app process.
 * Shizuku launches it in a separate process that carries the "shell" UID
 * (the same privilege level `adb shell` has). That is exactly the privilege
 * level `wm density` needs - no root required.
 */
class UserService : IUserService.Stub() {

    override fun execute(cmd: String) {
        try {
            val process = Runtime.getRuntime().exec(arrayOf("sh", "-c", cmd))
            process.waitFor()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun destroy() {
        System.exit(0)
    }
}
